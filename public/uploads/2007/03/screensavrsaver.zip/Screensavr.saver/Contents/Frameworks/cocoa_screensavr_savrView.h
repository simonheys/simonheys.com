//
//  cocoa_screensavr_savrView.h
//  cocoa_screensavr_savr
//
//  Created by Simon on 22/02/2007.
//  Copyright (c) 2007, __MyCompanyName__. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>

@class ConfigrController;
@class PreferenceController;
@class ScreensavrView;
@class ScreensavrController;

@interface cocoa_screensavr_savrView : ScreenSaverView 
{
	ScreensavrView *_screensavrView;
	PreferenceController *_preferences;
	ConfigrController *_configrController;
	ScreensavrController *_screensavrController;
}

@end
