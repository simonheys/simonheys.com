//
//  ScreensavrController.h
//  Screensavr
//
//  Created by Simon on 24/02/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ObjectiveFlickr/ObjectiveFlickr.h>

@class FlickrImageUrlProvider;
@class ScreensavrView;
@class PreferenceController;

@interface ScreensavrController : NSObject {
	ScreensavrView *_screensavrView;
	FlickrImageUrlProvider *_flickrImageUrlProvider;	
	OFFlickrContext *_flickrContext;
	OFFlickrInvocation *_flickrInvocation;
	PreferenceController *_preferences;
}
- (id)initWithPreferences:(PreferenceController *)preferences withScreensavrView:(ScreensavrView *)view;
-(void)setupImageProviderForNsId:(NSString *)nsId;

-(void)handleViewReadyForData:(ScreensavrView *)caller;

- (void)flickrImageUrlProvider:(FlickrImageUrlProvider*)provider imageUrl:(NSURL *)url;
- (void)flickrImageUrlProvider:(FlickrImageUrlProvider*)provider error:(int)errcode;

- (void)callNextImage;
- (void)start;
@end
