//
//  FlickrPhotosetUrlProvider.h
//  Screensavr
//
//  Created by Simon on 25/02/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "FlickrImageUrlProvider.h"


@interface FlickrPhotosetUrlProvider : FlickrImageUrlProvider {
	NSString *_photosetId;
}

-(id)initWithContext:(OFFlickrContext *)context delegate:(id)delegate photosetId:(NSString *)photosetId;
-(void)setPhotosetId:(NSString *)photosetId;
-(NSString *)photosetId;

@end
