//
//  cocoa_screensavr_savrView.h
//  cocoa_screensavr_savr
//
//  Created by Simon on 22/02/2007.
//  Copyright (c) 2007, __MyCompanyName__. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>

@class ConfigrController;
@class ScreensavrView;
@class ScreensavrController;
@class ImageRowsController;

@interface cocoa_screensavr_savrView : ScreenSaverView 
{
	ScreensavrView *_screensavrView;
	ConfigrController *_configrController;
	ScreensavrController *_screensavrController;
	NSRect _myFrame;
	ImageRowsController *_imageRows;
	BOOL _myIsPreview;
}
- (void) setScreensavrController:(ScreensavrController *)controller;
- (void) setImageRows:(ImageRowsController *)rows;
- (void) saveDataToDisk;
- (void) loadDataFromDisk;

@end
