//
//  FlickrPublicPhotosUrlProvider.h
//  Screensavr
//
//  Created by Simon on 25/02/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "FlickrImageUrlProvider.h"


@interface FlickrPublicPhotosUrlProvider : FlickrImageUrlProvider {
	NSString *_nsId;
}

-(id)initWithContext:(OFFlickrContext *)context delegate:(id)delegate nsId:(NSString *)nsId;
-(void)setNsId:(NSString *)nsId;
-(NSString *)nsId;

@end
