//
//  ScreensavrController.h
//  Screensavr
//
//  Created by Simon on 24/02/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <ObjectiveFlickr/ObjectiveFlickr.h>

@class FlickrImageUrlProvider;
@class ImageRowsController;

@interface ScreensavrController : NSObject <NSCoding>
{
	ImageRowsController *_imageRows;
	FlickrImageUrlProvider *_flickrImageUrlProvider;	
	OFFlickrContext *_flickrContext;
	OFFlickrInvocation *_flickrInvocation;
	int _imageCounter;
}
- (void) setImageRows:(ImageRowsController *)rows;

//- (id)initWithPreferences:(PreferenceController *)preferences;
-(void)setupImageProviderForNsId:(NSString *)nsId;

-(void)handleRowsReadyForData:(ImageRowsController *)caller;

- (void)flickrImageUrlProvider:(FlickrImageUrlProvider*)provider imageUrl:(NSURL *)url;
- (void)flickrImageUrlProvider:(FlickrImageUrlProvider*)provider error:(int)errcode;

- (void)callNextImage;
- (void)start;
- (void)deInit;

@end
