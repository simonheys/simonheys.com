//
//  ScreensavrView.h
//  Screensavr
//
//  Created by Simon on 17/02/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <QuartzCore/QuartzCore.h>
#import <OpenGL/OpenGL.h>
#import "ImageRowImageProviderProtocol.h";

@class BitmapLoader;

@interface ImageRowsController : NSObject <ImageRowImageProviderProtocol, NSCoding> 
{
	int _status;
	int _speed;
	int _width;
	float _height;
	float _largestImageHeight;
	float _lastImageWidth;
	BitmapLoader *_bitmapLoader;
	NSMutableArray *_rows;
	NSObject<ImageRowImageProviderProtocol> *_source;
}
-(id)initWithSize:(NSSize)size;
-(void)initEmptyRows;
-(void)loadImage:(NSURL *)imageUrl;
-(void)readyForNextImage; 
-(void)determineRowSizes;
-(void)deInit;
-(void)draw;
-(void)update;
-(float)width;
-(float)height;

@end
