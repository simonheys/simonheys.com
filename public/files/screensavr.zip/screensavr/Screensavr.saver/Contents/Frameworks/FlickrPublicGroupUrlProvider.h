//
//  FlickrPublicGroupUrlProvider.h
//  Screensavr
//
//  Created by Simon on 25/02/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "FlickrImageUrlProvider.h"


@interface FlickrPublicGroupUrlProvider : FlickrImageUrlProvider {
	NSString *_groupId;
}

-(id)initWithContext:(OFFlickrContext *)context delegate:(id)delegate groupId:(NSString *)groupId;
-(void)setGroupId:(NSString *)groupId;
-(NSString *)groupId;

@end
